# LUMORA — Premium E-commerce Starter

Files:
- index.html — complete storefront
- style.css — responsive luxury theme
- script.js — product filtering, search, cart, wishlist toast and demo checkout

## Run
Open `index.html` in any modern browser.

## Included
- Responsive mobile/desktop layout
- Lumora cream + deep green + gold brand system
- Hero section
- Categories
- Product catalog
- Category filters
- Search overlay
- Shopping cart with localStorage
- Newsletter interaction
- Reviews
- Footer
- Light blue glow interaction effect
- Demo checkout button

## Important
This is a front-end starter. For a real store, connect:
- Product database / admin panel
- Real product images
- Order management
- Payment gateway
- Delivery/shipping logic
- WhatsApp/Messenger links
- Customer authentication if needed

The demo currently uses generated CSS product illustrations, so it works without external image files.
